import string

s = 'The quick brown fox jumped over the lazy dog'
print(s)
print(string.capwords(s))
