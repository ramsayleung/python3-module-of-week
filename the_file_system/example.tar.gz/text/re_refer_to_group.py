import re

address = re.compile(
    r'''
    # The regular name
    (\w+) # first name
    \s+
    (([\w.]+)\s+)? # optional middle name of initial
    (\w+) # last name
    
    \s+
    
    <
    # The address:first_name.last_name@domain.tld
    (?P<email>
    \1 # first name
    \.
    \4 # last name
    @
    ([\w\d.]+\.)+ #domain name prefix
    (com|org|edu)
    )
    >
    ''',
    re.VERBOSE | re.IGNORECASE
)
candidates = [
    u'First Last <first.last@example.com>',
    u'Different Name <first.last@example.com>',
    u'First Middle Last <first.last@example.com>',
    u'First M.Last <first.last@example.com>',
]
for candidate in candidates:
    print('Candidate:', candidate)
    match = address.search(candidate)
    if match:
        print('  Match name :', match.group(1), match.group(4))
        print('  Match email:', match.group(5))
    else:
        print(' No Match')
