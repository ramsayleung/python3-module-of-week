from operator import *
a = -1
b = 5.0
c = 2
d = 6

print('a=', a)
print('b=', b)
print('c=', c)
print('d=', d)

print('\nPositive/Negative:')
print('abs(a)', abs(a))
print('neg(a)', neg(a))
print('neg(b)', neg(b))
print('pos(a)', pos(a))
print('pos(b)', pos(b))

print('\nArithmetic:')
print('add(a,b):', add(a, b))
print('floordiv(a,b):', floordiv(a, b))
print('floordiv(b,c):', floordiv(d, c))
print('mod(a,b):', mod(a, b))
print('mul(a,b):', mul(a, b))
print('sub (b,a): ', sub(b, a))
print('\nBitwise:')
print('and_(c,d):', and_(c, d))
print('invert(c):', invert(c))
print('lshift(c,d):', lshift(c, d))
print('or_(c,d):', or_(c, d))
print('rshift(d,c):', rshift(d, c))
print('xor(c,d):', xor(c, d))
