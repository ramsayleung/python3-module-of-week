for i in zip([1, 2, 3], ['a', 'b', 'c']):
    print(i)
