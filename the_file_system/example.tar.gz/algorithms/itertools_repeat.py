from itertools import repeat
for i in repeat('over-and-over', 5):
    print(i)
