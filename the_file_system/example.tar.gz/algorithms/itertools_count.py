from itertools import count
for i in zip(count(1, 2), ['a', 'b', 'c']):
    print(i)
