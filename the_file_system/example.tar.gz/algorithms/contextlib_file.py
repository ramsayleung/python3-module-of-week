with open('/tmp/pymotw.txt', 'wt') as f:
    f.write('contents go here')
