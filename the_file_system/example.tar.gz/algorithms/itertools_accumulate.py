from itertools import accumulate

print(list(accumulate(range(5))))

print(list(accumulate('abcd')))
