import pickle


class State:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return 'State({!r})'.format(self.__dict__)


class MyClass:
    def __init__(self, name):
        print('MyClass.__init__({})'.format(name))

    def _set_name(self, name):
        self.name = name
        self.computed = name[::-1]

    def __repr__(self):
        return 'MyClass({!r})(computed={!r})'.format(self.name, self.computed)

    def __getstate__(self):
        state = State(self.name)
        print('__getstate__->{!r}'.format(state))
        return state

    def __setstate__(self, state):
        print('__setstate__({!r})'.format(state))
        self._set_name(state.name)
