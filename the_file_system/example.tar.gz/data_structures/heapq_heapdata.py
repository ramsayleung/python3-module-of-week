# This is this section use the data in heapq_heapdata.py
data = [19, 9, 4, 10, 11]
