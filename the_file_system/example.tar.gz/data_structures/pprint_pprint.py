from pprint import pprint
from pprint_data import data
print('PRINT:')
print(data)
print()
print('PPRINT:')
pprint(data)
