from pprint import pprint
from pprint_data import data
pprint(data, depth=1)
pprint(data, depth=2)
