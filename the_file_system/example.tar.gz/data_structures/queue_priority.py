import functools
import queue
import threading


@functools.total_ordering
class Job:

    def __init__(self, priority, description):
        self.priority = priority
        self.description = description
        print('New job:', description)
        return

    def __eq__(self, other):
        try:
            return self.priority == other.priority
        except AttributeError:
            return NotImplemented

    def __lt__(self, other):
        try:
            return self.priority < other.priority
        except AttributeError:
            return NotImplemented

q = queue.PriorityQueue()
q.put(Job(3, 'Mid-level job'))
q.put(Job(4, 'Mid-level job'))
q.put(Job(5, 'Mid-level job'))
q.put(Job(6, 'Mid-level job'))
q.put(Job(10, 'Low-level job'))
q.put(Job(8, 'Low-level job'))
q.put(Job(1, 'Important job'))


def process_job(q):
    while True:
        next_job = q.get()
        print('Processing job:', next_job.description)
        q.task_done()

workers = [
    threading.Thread(target=process_job, args=(q,)),
    threading.Thread(target=process_job, args=(q,)),
]

for w in workers:
    w.setDaemon(True)
    w.start()
# block until all tasks are done
q.join()
