import datetime

print('Earliest:', datetime.date.min)
print('Latest:', datetime.date.max)
print('Resolution:', datetime.date.resolution)
