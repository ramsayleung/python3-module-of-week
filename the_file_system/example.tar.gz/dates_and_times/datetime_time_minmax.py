import datetime

print('Earliest:', datetime.time.min)
print('Latest:', datetime.time.max)
print('Resolution:', datetime.time.resolution)
