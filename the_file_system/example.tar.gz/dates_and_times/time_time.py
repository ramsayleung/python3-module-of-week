import time
print('The time is:', time.time())
