import calendar

c = calendar.TextCalendar(calendar.SUNDAY)
c.prmonth(2017, 7)
