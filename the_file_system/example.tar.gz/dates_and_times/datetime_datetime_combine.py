import datetime

t = datetime.time(1, 2, 3)
print('t:', t)

d = datetime.date.today()
print('d', d)

dt = datetime.datetime.combine(d, t)
print('dt', dt)
