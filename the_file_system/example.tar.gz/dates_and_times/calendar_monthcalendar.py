import calendar
import pprint

pprint.pprint(calendar.monthcalendar(2017, 7))
