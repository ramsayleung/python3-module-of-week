import decimal

t = (1, (1, 1), -3)
print('Input:', t)
print('Decimal:', decimal.Decimal(t))
