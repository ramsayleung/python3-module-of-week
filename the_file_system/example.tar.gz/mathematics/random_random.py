import random

for i in range(5):
    print('%04.3f' % random.random(), end=' ')
print()
