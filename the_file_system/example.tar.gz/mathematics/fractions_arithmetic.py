import fractions

f1 = fractions.Fraction(1, 2)
f2 = fractions.Fraction(3, 4)

print('{}+{}={}'.format(f1, f2, f1 + f2))
print('{}-{}={}'.format(f1, f2, f1 - f2))
print('{}/{}={}'.format(f1, f2, f1 / f2))
print('{}*{}={}'.format(f1, f2, f1 * f2))
