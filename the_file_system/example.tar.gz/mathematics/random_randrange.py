import random

for i in range(3):
    print(random.randrange(0, 100, 5), end=' ')
print()
