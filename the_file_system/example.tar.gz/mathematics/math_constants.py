import math

print(' pi: {:.30f}'.format(math.pi))
print(' e:{:.30f}'.format(math.e))
print('nan:{:.30f}'.format(math.nan))
print('inf:{:.30f}'.format(math.inf))
